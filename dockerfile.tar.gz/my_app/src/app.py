print("byte")
print("hi")
print("hello")
print("bye")
